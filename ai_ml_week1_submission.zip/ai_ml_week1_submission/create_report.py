from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import textwrap

ROOT = Path('/home/ubuntu/ai_ml_week1_submission')
ASSETS = ROOT/'report_assets'
SCREEN = ROOT/'screenshots'
ASSETS.mkdir(exist_ok=True)
SCREEN.mkdir(exist_ok=True)

try:
    mono = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 22)
    mono_small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 17)
except:
    mono = mono_small = ImageFont.load_default()

def make_code_image(src, out):
    lines = Path(src).read_text().splitlines()
    margin = 34; line_h = 29; width = 1500
    height = margin*2 + line_h*min(len(lines), 55) + 35
    img = Image.new('RGB', (width, height), '#111827')
    d = ImageDraw.Draw(img)
    d.rectangle((0,0,width,58), fill='#1f2937')
    d.ellipse((24,20,38,34), fill='#ef4444'); d.ellipse((48,20,62,34), fill='#f59e0b'); d.ellipse((72,20,86,34), fill='#22c55e')
    d.text((110,18), Path(src).name, font=mono_small, fill='#d1d5db')
    for i,line in enumerate(lines[:55]):
        y = 75 + i*line_h
        d.text((margin,y), f'{i+1:>3}  {line}', font=mono_small, fill='#e5e7eb')
    img.save(out)

def make_output_image(src, out):
    lines = Path(src).read_text().splitlines()
    margin=34; line_h=28; width=1500
    height=margin*2+line_h*len(lines)+35
    img=Image.new('RGB',(width,height),'#0b1220'); d=ImageDraw.Draw(img)
    d.rectangle((0,0,width,58), fill='#162033')
    d.ellipse((24,20,38,34), fill='#ef4444'); d.ellipse((48,20,62,34), fill='#f59e0b'); d.ellipse((72,20,86,34), fill='#22c55e')
    d.text((110,18), 'Terminal — sample execution', font=mono_small, fill='#d1d5db')
    for i,line in enumerate(lines):
        d.text((margin,75+i*line_h), line, font=mono_small, fill='#a7f3d0' if not line.startswith('Invalid') else '#fca5a5')
    img.save(out)

for name in ['student_management.py','smart_calculator.py','pattern_logic.py']:
    make_code_image(ROOT/'apps'/name, SCREEN/(name.replace('.py','_code.png')))
for name in ['student_output.txt','calculator_output.txt','pattern_output.txt']:
    make_output_image(ROOT/name, SCREEN/(name.replace('.txt','_output.png')))

# Word helpers
def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr(); shd = OxmlElement('w:shd'); shd.set(qn('w:fill'), fill); tcPr.append(shd)
def set_cell_text(cell, text, bold=False, color='FFFFFF'):
    cell.text=''; p=cell.paragraphs[0]; r=p.add_run(text); r.bold=bold; r.font.color.rgb=RGBColor.from_string(color); r.font.size=Pt(10)

def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run=paragraph.add_run('Page ')
    fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); paragraph._p.append(fld)

def add_heading(doc, text, level=1):
    p=doc.add_heading(text, level=level); p.style.font.color.rgb=RGBColor(31,78,121); return p

def add_caption(doc, text):
    p=doc.add_paragraph(text); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.runs[0].italic=True; p.runs[0].font.size=Pt(9); p.runs[0].font.color.rgb=RGBColor(89,89,89)

def add_img(doc, path, width=6.4):
    # Keep screenshots within a Word page while preserving their aspect ratio.
    from PIL import Image
    im=Image.open(path)
    max_h=1100
    if im.height > max_h:
        ratio=max_h/im.height
        resized=im.resize((int(im.width*ratio), max_h))
        tmp=Path(path).with_name(Path(path).stem+'_resized.png')
        resized.save(tmp)
        path=tmp
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run().add_picture(str(path), width=Inches(width))

doc=Document()
sec=doc.sections[0]; sec.top_margin=Inches(.7); sec.bottom_margin=Inches(.7); sec.left_margin=Inches(.8); sec.right_margin=Inches(.8)
# Header/footer
header=sec.header.paragraphs[0]; header.text='DG INTERNS HUB  |  AI/ML INTERNSHIP'; header.runs[0].font.size=Pt(8); header.runs[0].font.color.rgb=RGBColor(89,89,89)
add_page_number(sec.footer.paragraphs[0])
styles=doc.styles
styles['Normal'].font.name='Aptos'; styles['Normal'].font.size=Pt(10.5); styles['Normal'].paragraph_format.space_after=Pt(6)
# Cover
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.space_after=Pt(20)
r=p.add_run('AI/ML INTERNSHIP'); r.bold=True; r.font.size=Pt(18); r.font.color.rgb=RGBColor(31,78,121)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=p.add_run('WEEK 1 SUBMISSION'); r.bold=True; r.font.size=Pt(31); r.font.color.rgb=RGBColor(31,78,121)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=p.add_run('Python Fundamentals for AI'); r.italic=True; r.font.size=Pt(18); r.font.color.rgb=RGBColor(68,68,68)
doc.add_paragraph('')
t=doc.add_table(rows=4, cols=2); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
for row in t.rows:
    row.cells[0].width=Inches(1.8); row.cells[1].width=Inches(4.8)
labels=['Student','Program','Submission Type','Date']
vals=['Nooraleeman Adel Al-shawesh','DG Interns Hub','Week 1 Practical Tasks','October 2026']
for i,(a,b) in enumerate(zip(labels,vals)):
    shade(t.cell(i,0),'1F4E79'); set_cell_text(t.cell(i,0),a,True)
    shade(t.cell(i,1),'EAF2F8'); set_cell_text(t.cell(i,1),b,False,'1F1F1F')
doc.add_paragraph('')
p=doc.add_paragraph('This report documents the design, implementation, testing, and sample execution of three Python applications created for the first week of the AI/ML Internship.'); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
# TOC-like overview
add_heading(doc,'1. Executive Summary')
doc.add_paragraph('The submission demonstrates core Python fundamentals required for AI/ML learning: variables and data types, input/output, operators, conditional statements, loops, functions, lists, dictionaries, validation, and basic algorithmic thinking. All applications were written in Python only and tested in the execution environment.')
add_heading(doc,'2. Learning Objectives Covered')
t=doc.add_table(rows=1, cols=2); t.alignment=WD_TABLE_ALIGNMENT.CENTER
for i,h in enumerate(['Fundamental','How it appears in the submission']): shade(t.cell(0,i),'1F4E79'); set_cell_text(t.cell(0,i),h,True)
items=[('Variables and data types','Numbers, strings, lists, dictionaries, and Boolean values.'),('Input / output','Interactive prompts and formatted result tables.'),('Operators','Arithmetic, comparison, modulo, and membership operations.'),('Conditions','Grade decisions, menu routing, and validation branches.'),('Loops','Continuous menus, mark collection, Fibonacci generation, and prime testing.'),('Functions','Reusable calculation, validation, calculator, and logic functions.')]
for a,b in items:
    cells=t.add_row().cells; shade(cells[0],'D9EAF7'); set_cell_text(cells[0],a,True,'1F1F1F'); set_cell_text(cells[1],b,False,'1F1F1F')
# student
add_heading(doc,'3. Task 1 — Student Management System')
doc.add_paragraph('The program stores multiple student records in a list of dictionaries. For each student, it collects a name and marks for any number of subjects, calculates the total and average percentage, and assigns a grade using the requested scale. Input validation prevents empty names, non-numeric marks, and marks outside the 0–100 range.')
add_img(doc, SCREEN/'student_management_code.png', 6.4); add_caption(doc,'Figure 1. Student Management System source code captured from the execution environment.')
add_img(doc, SCREEN/'student_output_output.png', 6.4); add_caption(doc,'Figure 2. Sample output showing two saved students and their calculated results.')
# calc
add_heading(doc,'4. Task 2 — Smart Calculator')
doc.add_paragraph('The calculator uses one function per arithmetic operation and a dictionary to map menu choices to functions. A while loop keeps the application running until the user selects Exit. Division by zero is handled safely with a clear error message.')
add_img(doc, SCREEN/'smart_calculator_code.png', 6.4); add_caption(doc,'Figure 3. Smart Calculator source code captured from the execution environment.')
add_img(doc, SCREEN/'calculator_output_output.png', 6.4); add_caption(doc,'Figure 4. Sample calculator output, including the division-by-zero safeguard.')
# logic
add_heading(doc,'5. Task 3 — Pattern and Logic Building')
doc.add_paragraph('Two logic problems were completed: (1) Fibonacci series generation using a for loop and tuple assignment, and (2) prime-number checking using a while loop that tests divisors only up to the square root of the number.')
add_img(doc, SCREEN/'pattern_logic_code.png', 6.4); add_caption(doc,'Figure 5. Fibonacci and prime-number checker source code.')
add_img(doc, SCREEN/'pattern_output_output.png', 6.4); add_caption(doc,'Figure 6. Sample output for Fibonacci generation and prime checking.')
# testing
add_heading(doc,'6. Testing and Quality Checks')
doc.add_paragraph('The reusable functions were tested with automated assertions covering all grade boundaries, arithmetic operations, Fibonacci output, and both prime and non-prime cases. The test suite completed successfully in the same environment used to generate the screenshots.')
add_img(doc, ASSETS/'test_result.png', 6.4); add_caption(doc,'Figure 7. Automated test result: all checks passed.')
# files and run
add_heading(doc,'7. How to Run')
doc.add_paragraph('Open a terminal in the submission folder and run the following commands:')
for cmd in ['python3 apps/student_management.py','python3 apps/smart_calculator.py','python3 apps/pattern_logic.py','python3 tests/test_apps.py']:
    p=doc.add_paragraph(style='Intense Quote'); p.add_run(cmd)
doc.add_paragraph('The three applications use only the Python standard library. No paid tools or external services are required.')
# reflection
add_heading(doc,'8. Short Reflection')
doc.add_paragraph('This week’s work strengthened the ability to break a problem into functions, validate user input, select suitable data structures, and control program flow. These are foundational skills for writing reliable data-processing and machine-learning code in later weeks.')
# submission checklist
add_heading(doc,'9. Submission Checklist')
for item in ['Student Management System completed with multiple-student storage','Smart Calculator completed with functions, menu, and continuous loop','Two logic problems completed: Fibonacci and prime checker','Code screenshots and output screenshots included','Automated checks passed','LinkedIn draft prepared for posting and tagging DG Interns Hub']:
    p=doc.add_paragraph(style='List Bullet'); p.add_run(item)
# linkedin note
add_heading(doc,'10. LinkedIn Posting Draft')
doc.add_paragraph('A ready-to-post LinkedIn draft is included as LinkedIn_Post.txt in the submission folder. The draft describes the completed work and includes relevant hashtags. It should be reviewed and posted by the student from their own LinkedIn account, tagging DG Interns Hub.')
# save
report_dir=ROOT/'report'; report_dir.mkdir(exist_ok=True)
docx_path=report_dir/'AI_ML_Week_1_Report.docx'; doc.save(docx_path)
print(docx_path)
