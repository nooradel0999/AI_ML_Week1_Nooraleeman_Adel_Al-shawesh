"""Professional GUI Student Management System."""
import tkinter as tk
from tkinter import ttk, messagebox

class StudentApp:
    def __init__(self, root, demo=False):
        self.root = root; self.root.title('DG Interns Hub | Student Management'); self.root.geometry('920x650'); self.root.configure(bg='#F4F7FB')
        self.students=[]; self._style(); self._build()
        if demo: self.root.after(500, self.demo)
    def _style(self):
        s=ttk.Style(); s.theme_use('clam'); s.configure('TButton',font=('DejaVu Sans',11),padding=8); s.configure('Treeview',font=('DejaVu Sans',11),rowheight=32); s.configure('Treeview.Heading',font=('DejaVu Sans',11,'bold')); s.configure('TLabel',background='#F4F7FB',font=('DejaVu Sans',11))
    def _build(self):
        top=tk.Frame(self.root,bg='#173B67',height=92); top.pack(fill='x'); tk.Label(top,text='STUDENT MANAGEMENT SYSTEM',bg='#173B67',fg='white',font=('DejaVu Sans',22,'bold')).pack(anchor='w',padx=28,pady=(18,2)); tk.Label(top,text='DG Interns Hub  •  Python Fundamentals for AI',bg='#173B67',fg='#BFD7F2',font=('DejaVu Sans',11)).pack(anchor='w',padx=30)
        form=ttk.LabelFrame(self.root,text='  Add Student Record  ',padding=16); form.pack(fill='x',padx=28,pady=22)
        ttk.Label(form,text='Student name').grid(row=0,column=0,sticky='w',padx=8,pady=6); self.name=ttk.Entry(form,width=28); self.name.grid(row=1,column=0,padx=8)
        ttk.Label(form,text='Marks (comma-separated)').grid(row=0,column=1,sticky='w',padx=8,pady=6); self.marks=ttk.Entry(form,width=32); self.marks.grid(row=1,column=1,padx=8)
        ttk.Button(form,text='Add Student',command=self.add_student).grid(row=1,column=2,padx=14); ttk.Button(form,text='Clear',command=self.clear).grid(row=1,column=3,padx=4)
        table=ttk.LabelFrame(self.root,text='  Student Results  ',padding=12); table.pack(fill='both',expand=True,padx=28,pady=(0,22))
        cols=('name','total','percentage','grade'); self.tree=ttk.Treeview(table,columns=cols,show='headings');
        for c,h,w in zip(cols,['Student Name','Total Marks','Percentage','Grade'],[330,160,180,120]): self.tree.heading(c,text=h); self.tree.column(c,width=w,anchor='center' if c!='name' else 'w')
        self.tree.pack(fill='both',expand=True); self.status=tk.Label(self.root,text='Ready to add student records',bg='#F4F7FB',fg='#52667A',font=('DejaVu Sans',10)); self.status.pack(anchor='w',padx=30,pady=(0,12))
    def add_student(self):
        try:
            name=self.name.get().strip(); marks=[float(x.strip()) for x in self.marks.get().split(',') if x.strip()]
            if not name or not marks or any(x<0 or x>100 for x in marks): raise ValueError
            total=sum(marks); pct=total/len(marks); grade='A' if pct>=90 else 'B' if pct>=75 else 'C' if pct>=50 else 'Fail'; self.students.append((name,total,pct,grade)); self.tree.insert('', 'end', values=(name,f'{total:.2f}',f'{pct:.2f}%',grade)); self.status.config(text=f"Added {name} successfully • {len(marks)} subjects • Grade {grade}"); self.clear()
        except ValueError: messagebox.showerror('Invalid input','Enter a name and marks from 0 to 100, separated by commas.')
    def clear(self): self.name.delete(0,'end'); self.marks.delete(0,'end')
    def demo(self):
        for n,m in [('Nooraleeman Adel Al-shawesh','95,82,61'),('Sara Ahmed','48,72')]: self.name.insert(0,n); self.marks.insert(0,m); self.add_student()
        self.root.update()
if __name__=='__main__':
    r=tk.Tk(); StudentApp(r,'--demo' in __import__('sys').argv); r.mainloop()
