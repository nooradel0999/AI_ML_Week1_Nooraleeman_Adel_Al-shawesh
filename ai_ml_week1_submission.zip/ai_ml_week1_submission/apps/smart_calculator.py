"""Smart Calculator - AI/ML Internship Week 1."""


def add(a: float, b: float) -> float:
    return a + b


def subtract(a: float, b: float) -> float:
    return a - b


def multiply(a: float, b: float) -> float:
    return a * b


def divide(a: float, b: float) -> float:
    if b == 0:
        raise ZeroDivisionError("Cannot divide by zero.")
    return a / b


def read_number(prompt: str) -> float:
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Invalid number. Please try again.")


def main() -> None:
    operations = {"1": ("Addition", add), "2": ("Subtraction", subtract),
                  "3": ("Multiplication", multiply), "4": ("Division", divide)}
    print("SMART CALCULATOR")
    while True:
        print("\n1. Add\n2. Subtract\n3. Multiply\n4. Divide\n5. Exit")
        choice = input("Choose an operation: ").strip()
        if choice == "5":
            print("Calculator closed.")
            break
        if choice not in operations:
            print("Invalid choice. Please select 1-5.")
            continue
        first = read_number("Enter first number: ")
        second = read_number("Enter second number: ")
        label, operation = operations[choice]
        try:
            result = operation(first, second)
            print(f"{label}: {first:g} and {second:g} = {result:g}")
        except ZeroDivisionError as error:
            print(f"Error: {error}")


if __name__ == "__main__":
    main()
