"""Professional GUI Smart Calculator."""
import tkinter as tk
from tkinter import ttk, messagebox
class CalculatorApp:
    def __init__(self,root,demo=False):
        self.root=root; root.title('DG Interns Hub | Smart Calculator'); root.geometry('620x560'); root.configure(bg='#F4F7FB'); self._style(); self._build();
        if demo: root.after(500,self.demo)
    def _style(self):
        s=ttk.Style(); s.theme_use('clam'); s.configure('TButton',font=('DejaVu Sans',12,'bold'),padding=10); s.configure('TLabel',background='#F4F7FB',font=('DejaVu Sans',11))
    def _build(self):
        top=tk.Frame(self.root,bg='#173B67',height=92); top.pack(fill='x'); tk.Label(top,text='SMART CALCULATOR',bg='#173B67',fg='white',font=('DejaVu Sans',23,'bold')).pack(anchor='w',padx=28,pady=(18,2)); tk.Label(top,text='Functions • Menu System • Safe Division',bg='#173B67',fg='#BFD7F2',font=('DejaVu Sans',11)).pack(anchor='w',padx=30)
        card=ttk.LabelFrame(self.root,text='  Calculation  ',padding=20); card.pack(fill='x',padx=28,pady=24)
        ttk.Label(card,text='First number').grid(row=0,column=0,sticky='w',pady=6); self.a=ttk.Entry(card,width=24); self.a.grid(row=1,column=0,padx=(0,18))
        ttk.Label(card,text='Second number').grid(row=0,column=1,sticky='w',pady=6); self.b=ttk.Entry(card,width=24); self.b.grid(row=1,column=1)
        ops=ttk.LabelFrame(self.root,text='  Choose Operation  ',padding=16); ops.pack(fill='x',padx=28,pady=(0,20))
        for i,(label,op) in enumerate([('＋ Add','+'),('− Subtract','-'),('× Multiply','*'),('÷ Divide','/')]): ttk.Button(ops,text=label,command=lambda o=op:self.calculate(o)).grid(row=0,column=i,padx=5,sticky='ew'); ops.columnconfigure(i,weight=1)
        self.result=tk.Label(self.root,text='Result will appear here',bg='#EAF2F8',fg='#173B67',font=('DejaVu Sans',22,'bold'),height=3); self.result.pack(fill='x',padx=28,pady=10)
        self.status=tk.Label(self.root,text='Ready',bg='#F4F7FB',fg='#52667A',font=('DejaVu Sans',10)); self.status.pack(pady=12)
    def calculate(self,op):
        try:
            a=float(self.a.get()); b=float(self.b.get());
            if op=='+': val=a+b
            elif op=='-': val=a-b
            elif op=='*': val=a*b
            else:
                if b==0: raise ZeroDivisionError
                val=a/b
            self.result.config(text=f'{a:g} {op} {b:g} = {val:g}'); self.status.config(text='Calculation completed successfully')
        except ZeroDivisionError: self.result.config(text='Cannot divide by zero'); self.status.config(text='Please enter a non-zero second number')
        except ValueError: messagebox.showerror('Invalid input','Please enter valid numbers.')
    def demo(self): self.a.insert(0,'12'); self.b.insert(0,'8'); self.calculate('+'); self.root.update()
if __name__=='__main__':
    r=tk.Tk(); CalculatorApp(r,'--demo' in __import__('sys').argv); r.mainloop()
