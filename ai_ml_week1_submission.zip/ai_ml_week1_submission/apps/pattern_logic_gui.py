"""Professional GUI Pattern and Logic Builder."""
import tkinter as tk
from tkinter import ttk, messagebox
class LogicApp:
    def __init__(self,root,demo=False):
        self.root=root; root.title('DG Interns Hub | Pattern + Logic'); root.geometry('760x560'); root.configure(bg='#F4F7FB'); self._style(); self._build();
        if demo: root.after(500,self.demo)
    def _style(self):
        s=ttk.Style(); s.theme_use('clam'); s.configure('TButton',font=('DejaVu Sans',11,'bold'),padding=9); s.configure('TLabel',background='#F4F7FB',font=('DejaVu Sans',11))
    def _build(self):
        top=tk.Frame(self.root,bg='#173B67',height=92); top.pack(fill='x'); tk.Label(top,text='PATTERN + LOGIC BUILDER',bg='#173B67',fg='white',font=('DejaVu Sans',22,'bold')).pack(anchor='w',padx=28,pady=(18,2)); tk.Label(top,text='Fibonacci Series  •  Prime Number Checker',bg='#173B67',fg='#BFD7F2',font=('DejaVu Sans',11)).pack(anchor='w',padx=30)
        card=ttk.LabelFrame(self.root,text='  Fibonacci Series  ',padding=18); card.pack(fill='x',padx=28,pady=22); ttk.Label(card,text='Number of terms').grid(row=0,column=0,sticky='w'); self.count=ttk.Entry(card,width=18); self.count.grid(row=1,column=0,pady=8); ttk.Button(card,text='Generate Series',command=self.fib).grid(row=1,column=1,padx=18)
        self.fibout=tk.Label(card,text='Series output will appear here',bg='#EAF2F8',fg='#173B67',font=('DejaVu Sans',14,'bold'),anchor='w',padx=12); self.fibout.grid(row=2,column=0,columnspan=2,sticky='ew',pady=(12,0))
        card2=ttk.LabelFrame(self.root,text='  Prime Number Checker  ',padding=18); card2.pack(fill='x',padx=28,pady=(0,22)); ttk.Label(card2,text='Enter an integer').grid(row=0,column=0,sticky='w'); self.num=ttk.Entry(card2,width=18); self.num.grid(row=1,column=0,pady=8); ttk.Button(card2,text='Check Number',command=self.prime).grid(row=1,column=1,padx=18); self.primeout=tk.Label(card2,text='Check result will appear here',bg='#EAF2F8',fg='#173B67',font=('DejaVu Sans',14,'bold'),anchor='w',padx=12); self.primeout.grid(row=2,column=0,columnspan=2,sticky='ew',pady=(12,0))
        self.status=tk.Label(self.root,text='Ready',bg='#F4F7FB',fg='#52667A',font=('DejaVu Sans',10)); self.status.pack(pady=6)
    def fib(self):
        try: n=int(self.count.get()); a,b=0,1; out=[];
        except ValueError: messagebox.showerror('Invalid input','Enter a positive whole number.'); return
        if n<1 or n>30: messagebox.showerror('Invalid input','Choose a number from 1 to 30.'); return
        out=[]; a,b=0,1
        for _ in range(n): out.append(a); a,b=b,a+b
        self.fibout.config(text='Fibonacci:  ' + '   '.join(map(str,out))); self.status.config(text='Fibonacci series generated successfully')
    def prime(self):
        try: n=int(self.num.get())
        except ValueError: messagebox.showerror('Invalid input','Enter an integer.'); return
        prime=n>=2 and all(n%d for d in range(2,int(n**0.5)+1)); self.primeout.config(text=f'{n} is '+('PRIME' if prime else 'NOT PRIME')); self.status.config(text='Prime check completed successfully')
    def demo(self): self.count.insert(0,'8'); self.fib(); self.num.insert(0,'29'); self.prime(); self.root.update()
if __name__=='__main__':
    r=tk.Tk(); LogicApp(r,'--demo' in __import__('sys').argv); r.mainloop()
