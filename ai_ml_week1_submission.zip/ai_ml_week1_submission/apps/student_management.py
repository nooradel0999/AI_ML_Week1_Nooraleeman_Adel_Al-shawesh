"""Student Management System - AI/ML Internship Week 1."""


def get_valid_mark(subject_name: str) -> float:
    """Read one mark between 0 and 100."""
    while True:
        try:
            mark = float(input(f"Enter marks for {subject_name} (0-100): "))
            if 0 <= mark <= 100:
                return mark
            print("Please enter a mark from 0 to 100.")
        except ValueError:
            print("Invalid input. Please enter a number.")


def calculate_grade(percentage: float) -> str:
    """Return the grade for a percentage."""
    if percentage >= 90:
        return "A"
    if percentage >= 75:
        return "B"
    if percentage >= 50:
        return "C"
    return "Fail"


def add_student(students: list[dict]) -> None:
    """Collect one student's details and append a record to the list."""
    name = input("Enter student name: ").strip()
    while not name:
        print("Name cannot be empty.")
        name = input("Enter student name: ").strip()

    number_of_subjects = 0
    while number_of_subjects < 1:
        try:
            number_of_subjects = int(input("Enter number of subjects: "))
            if number_of_subjects < 1:
                print("Enter at least one subject.")
        except ValueError:
            print("Please enter a whole number.")

    marks = [get_valid_mark(f"Subject {i}") for i in range(1, number_of_subjects + 1)]
    total = sum(marks)
    percentage = total / number_of_subjects
    students.append({
        "name": name,
        "marks": marks,
        "total": total,
        "percentage": percentage,
        "grade": calculate_grade(percentage),
    })
    print(f"Student '{name}' added successfully.\n")


def display_students(students: list[dict]) -> None:
    """Display all saved student records."""
    if not students:
        print("No student records available.")
        return
    print("\n" + "=" * 72)
    print(f"{'Name':<24}{'Total':>12}{'Percentage':>16}{'Grade':>12}")
    print("-" * 72)
    for student in students:
        print(f"{student['name']:<24}{student['total']:>12.2f}{student['percentage']:>15.2f}%{student['grade']:>12}")
    print("=" * 72)


def main() -> None:
    students: list[dict] = []
    print("STUDENT MANAGEMENT SYSTEM")
    print("Grade scale: 90+ A | 75-89 B | 50-74 C | Below 50 Fail\n")
    while True:
        print("1. Add student\n2. Display students\n3. Exit")
        choice = input("Choose an option: ").strip()
        if choice == "1":
            add_student(students)
        elif choice == "2":
            display_students(students)
        elif choice == "3":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please select 1, 2, or 3.\n")


if __name__ == "__main__":
    main()
