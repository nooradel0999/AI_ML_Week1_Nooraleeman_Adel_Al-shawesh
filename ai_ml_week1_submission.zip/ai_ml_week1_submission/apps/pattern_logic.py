"""Pattern and Logic Building - AI/ML Internship Week 1."""


def fibonacci_series(count: int) -> list[int]:
    """Return the first count Fibonacci numbers."""
    series: list[int] = []
    first, second = 0, 1
    for _ in range(count):
        series.append(first)
        first, second = second, first + second
    return series


def is_prime(number: int) -> bool:
    """Return True when number is prime."""
    if number < 2:
        return False
    divisor = 2
    while divisor * divisor <= number:
        if number % divisor == 0:
            return False
        divisor += 1
    return True


def main() -> None:
    print("PATTERN + LOGIC BUILDING")
    count = int(input("How many Fibonacci terms? "))
    print("Fibonacci:", " ".join(map(str, fibonacci_series(count))))
    number = int(input("Enter a number to check for prime: "))
    print(f"{number} is {'prime' if is_prime(number) else 'not prime'}.")


if __name__ == "__main__":
    main()
