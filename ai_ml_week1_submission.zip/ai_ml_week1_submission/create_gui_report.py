from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
ROOT=Path('/home/ubuntu/ai_ml_week1_submission'); IMG=ROOT/'gui_screenshots'; OUT=ROOT/'report'

def shade(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=OxmlElement('w:shd'); shd.set(qn('w:fill'),fill); tcPr.append(shd)
def celltext(cell,text,bold=False,color='FFFFFF'):
    cell.text=''; r=cell.paragraphs[0].add_run(text); r.bold=bold; r.font.size=Pt(10); r.font.color.rgb=RGBColor.from_string(color)
def heading(doc,text,level=1):
    p=doc.add_heading(text,level); p.style.font.color.rgb=RGBColor(23,59,103); return p
def picture(doc,path,width=6.4):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run().add_picture(str(path),width=Inches(width))
def caption(doc,text):
    p=doc.add_paragraph(text); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    for r in p.runs: r.italic=True; r.font.size=Pt(9); r.font.color.rgb=RGBColor(89,89,89)
def page_num(p):
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER; p.add_run('Page '); fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); p._p.append(fld)

doc=Document(); sec=doc.sections[0]; sec.top_margin=Inches(.7); sec.bottom_margin=Inches(.7); sec.left_margin=Inches(.8); sec.right_margin=Inches(.8)
sec.header.paragraphs[0].text='DG INTERNS HUB  |  AI/ML INTERNSHIP'; sec.header.paragraphs[0].runs[0].font.size=Pt(8); page_num(sec.footer.paragraphs[0])
doc.styles['Normal'].font.name='Aptos'; doc.styles['Normal'].font.size=Pt(10.5); doc.styles['Normal'].paragraph_format.space_after=Pt(6)
# cover
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=p.add_run('AI/ML INTERNSHIP'); r.bold=True; r.font.size=Pt(18); r.font.color.rgb=RGBColor(23,59,103)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=p.add_run('WEEK 1 GUI APPLICATIONS'); r.bold=True; r.font.size=Pt(28); r.font.color.rgb=RGBColor(23,59,103)
p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER; r=p.add_run('Python Fundamentals for AI'); r.italic=True; r.font.size=Pt(17); r.font.color.rgb=RGBColor(68,68,68)
doc.add_paragraph('')
t=doc.add_table(rows=4,cols=2); t.alignment=WD_TABLE_ALIGNMENT.CENTER
for i,(a,b) in enumerate([('Student','Nooraleeman Adel Al-shawesh'),('Program','DG Interns Hub'),('Deliverable','Professional desktop GUI applications'),('Date','October 2026')]):
    shade(t.cell(i,0),'173B67'); celltext(t.cell(i,0),a,True); shade(t.cell(i,1),'EAF2F8'); celltext(t.cell(i,1),b,False,'1F1F1F')
doc.add_paragraph('')
p=doc.add_paragraph('This report presents three polished desktop applications built with Python Tkinter. Each interface was executed in the sandbox environment and captured while displaying real calculated results.'); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
heading(doc,'1. Project Overview')
doc.add_paragraph('The original command-line tasks were upgraded into practical graphical applications so that users can enter data through clear forms, press action buttons, and view results in structured panels. The applications use Python and the standard-library Tkinter toolkit; no paid tools or third-party runtime packages are required.')
heading(doc,'2. Applications Delivered')
t=doc.add_table(rows=1,cols=3); t.alignment=WD_TABLE_ALIGNMENT.CENTER
for i,h in enumerate(['Application','GUI Features','Demonstrated Result']): shade(t.cell(0,i),'173B67'); celltext(t.cell(0,i),h,True)
rows=[('Student Management','Student form, marks entry, results table, grade calculation','Two students with totals, percentages, and grades'),('Smart Calculator','Number fields and four operation buttons','12 + 8 = 20'),('Pattern + Logic Builder','Fibonacci generator and prime checker panels','Fibonacci terms and 29 identified as prime')]
for row in rows:
    cells=t.add_row().cells
    for i,val in enumerate(row): shade(cells[i],'EAF2F8' if i==0 else 'F7FBFF'); celltext(cells[i],val,i==0,'1F1F1F')
heading(doc,'3. Student Management System — GUI Output')
doc.add_paragraph('The interface accepts a student name and comma-separated marks. It calculates total marks, percentage, and grade, then displays each record in a professional results table. The captured run demonstrates the requested multiple-student bonus using a list of records.')
picture(doc,IMG/'gui_student_management_output.png'); caption(doc,'Figure 1. Student Management System GUI displaying two completed student records.')
heading(doc,'4. Smart Calculator — GUI Output')
doc.add_paragraph('The calculator provides dedicated Add, Subtract, Multiply, and Divide buttons. It uses reusable functions and displays the operation result in a prominent result card. The interface also includes safe input handling for invalid values and division by zero.')
picture(doc,IMG/'gui_smart_calculator_output.png'); caption(doc,'Figure 2. Smart Calculator GUI displaying the calculated result 12 + 8 = 20.')
heading(doc,'5. Pattern + Logic Builder — GUI Output')
doc.add_paragraph('The logic application presents two independent panels. The Fibonacci panel generates a requested number of terms, while the Prime Number Checker determines whether an integer is prime. Both outputs are displayed directly in the interface.')
picture(doc,IMG/'gui_pattern_logic_output.png'); caption(doc,'Figure 3. Pattern + Logic GUI displaying Fibonacci output and the prime result for 29.')
heading(doc,'6. Python Fundamentals Demonstrated')
for item in ['Variables and data types for names, marks, numbers, and results','Input and output through Tkinter Entry, Label, Table, and Button widgets','Arithmetic and comparison operators for calculations and grade decisions','Conditional statements for grade bands, operation selection, and prime logic','Loops for collecting records, generating Fibonacci terms, and checking divisors','Functions and event handlers for reusable, organized code','Lists and dictionaries/data records for multiple students']:
    doc.add_paragraph(item,style='List Bullet')
heading(doc,'7. How to Run the GUI Applications')
doc.add_paragraph('From the project folder, run any application with Python 3:')
for cmd in ['python3 apps/student_management_gui.py','python3 apps/smart_calculator_gui.py','python3 apps/pattern_logic_gui.py']:
    p=doc.add_paragraph(style='Intense Quote'); p.add_run(cmd)
doc.add_paragraph('The three files support a --demo flag used to populate representative data for the captured screenshots:')
for cmd in ['python3 apps/student_management_gui.py --demo','python3 apps/smart_calculator_gui.py --demo','python3 apps/pattern_logic_gui.py --demo']:
    p=doc.add_paragraph(style='Intense Quote'); p.add_run(cmd)
heading(doc,'8. Source Code Screenshots')
doc.add_paragraph('The code screenshots below are included alongside the GUI output screenshots. They show the Python source used to build the three desktop applications.')
picture(doc,ROOT/'code_screenshots/student_management_gui_code.png',6.4); caption(doc,'Figure 4. Student Management System GUI source code.')
picture(doc,ROOT/'code_screenshots/smart_calculator_gui_code.png',6.4); caption(doc,'Figure 5. Smart Calculator GUI source code.')
picture(doc,ROOT/'code_screenshots/pattern_logic_gui_code.png',6.4); caption(doc,'Figure 6. Pattern + Logic Builder GUI source code.')
heading(doc,'9. Quality and Submission Checklist')
for item in ['All three GUI applications compile successfully','Screenshots were captured from real running Tkinter windows','Student totals, percentages, and grades are visible in the interface','Calculator result is visible in the result card','Fibonacci and prime-check outputs are visible in the logic interface','Original CLI versions and automated tests remain included for reference','LinkedIn posting draft is included and ready for review']:
    doc.add_paragraph(item,style='List Bullet')
heading(doc,'10. LinkedIn Posting Draft')
doc.add_paragraph('The file LinkedIn_Post.txt contains a ready-to-post English draft describing the completed Week 1 work. The student should review it and publish it from their own LinkedIn account while tagging DG Interns Hub.')
OUT.mkdir(exist_ok=True); path=OUT/'AI_ML_Week_1_Report.docx'; doc.save(path); print(path)
