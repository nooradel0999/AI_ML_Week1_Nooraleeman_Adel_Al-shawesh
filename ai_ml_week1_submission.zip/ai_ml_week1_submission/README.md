# AI/ML Internship – Week 1 Submission

**Student:** Nooraleeman Adel Al-shawesh  
**Program:** DG Interns Hub  
**Topic:** Python Fundamentals for AI

## Included Applications

1. `apps/student_management.py` – multi-student management using lists and dictionaries, total, percentage, and grade calculation.
2. `apps/smart_calculator.py` – menu-based calculator using functions and a continuous loop.
3. `apps/pattern_logic.py` – Fibonacci series and prime-number checker.
4. `tests/test_apps.py` – automated checks for the core functions.
5. `report/AI_ML_Week_1_Report.docx` – professional report with code and output screenshots.
6. `report/AI_ML_Week_1_Report.pdf` – PDF copy for convenient submission.

## Run

```bash
python3 apps/student_management.py
python3 apps/smart_calculator.py
python3 apps/pattern_logic.py
python3 tests/test_apps.py
```

No third-party Python packages are required to run the applications.

## Visual Evidence

The folder `screenshots/interfaces_and_results/` contains separate screenshots of each application interface and its sample execution result:

- `interface_student_management.png` / `result_student_management.png`
- `interface_smart_calculator.png` / `result_smart_calculator.png`
- `interface_pattern_logic.png` / `result_pattern_logic.png`

## Output Screenshots

The folder `output_screenshots/` contains the actual terminal output screenshots captured after running the applications:

- `output_student_management.png`
- `output_smart_calculator.png`
- `output_pattern_logic.png`

## Professional GUI Edition

The primary submission now includes three Tkinter desktop GUI applications:

- `apps/student_management_gui.py`
- `apps/smart_calculator_gui.py`
- `apps/pattern_logic_gui.py`

Their real GUI result screenshots are in `gui_screenshots/`. Run each with `--demo` to reproduce the captured results.

## Code Screenshots

The folder `code_screenshots/` contains source-code screenshots for all three GUI applications. These were added without removing any GUI output screenshots.
