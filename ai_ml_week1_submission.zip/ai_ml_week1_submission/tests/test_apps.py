import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "apps"))
from student_management import calculate_grade
from smart_calculator import add, subtract, multiply, divide
from pattern_logic import fibonacci_series, is_prime


def test_grades():
    assert calculate_grade(95) == "A"
    assert calculate_grade(80) == "B"
    assert calculate_grade(60) == "C"
    assert calculate_grade(40) == "Fail"


def test_calculator():
    assert add(2, 3) == 5
    assert subtract(8, 3) == 5
    assert multiply(4, 2.5) == 10
    assert divide(9, 3) == 3


def test_logic():
    assert fibonacci_series(7) == [0, 1, 1, 2, 3, 5, 8]
    assert is_prime(29)
    assert not is_prime(30)


if __name__ == "__main__":
    tests = [test_grades, test_calculator, test_logic]
    for test in tests:
        test()
        print(f"PASS {test.__name__}")
    print(f"{len(tests)} tests passed")
